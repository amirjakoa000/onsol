import React from 'react';
import { X, HelpCircle, CheckCircle, ArrowLeft, ArrowRight, Clock, Video } from 'lucide-react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
      <div className="w-full max-w-2xl rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 md:p-8 text-white space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-6 h-6 text-cyan-400" />
            <h3 className="text-xl font-bold font-['Unbounded']">Ойын ережесі мен нұсқаулық</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs sm:text-sm text-slate-300">
          <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-2">
            <h4 className="font-bold text-white flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-300 flex items-center justify-center text-xs font-black">
                1
              </span>
              Тақтадағы сұрақ пен 10 секунд
            </h4>
            <p className="text-slate-400">
              Тақтаның жоғарғы жағында сұрақ шығады. Ортада 10 секундтық таймер кері санай бастайды.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-2">
            <h4 className="font-bold text-white flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-300 flex items-center justify-center text-xs font-black">
                2
              </span>
              Сол жақ па, әлде Оң жақ па?
            </h4>
            <p className="text-slate-400">
              Тақтаның төменгі сол жағында <strong>Нұсқа А</strong>, оң жағында <strong>Нұсқа В</strong> тұрады.
              Оқушылар өздері дұрыс деп санайтын нұсқаның жағына (сыныптың сол немесе оң жағына) тұра қалуы керек!
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-2">
            <h4 className="font-bold text-white flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center text-xs font-black">
                3
              </span>
              Камера мен Қақ ортадағы сызық
            </h4>
            <p className="text-slate-400">
              Камера тақтаның қақ ортасынан бөлгіш сызық жүргізеді және қай жақта оқушылар көбірек тұрғанын автоматты түрде санайды.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-2">
            <h4 className="font-bold text-white flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-rose-500/20 text-rose-300 flex items-center justify-center text-xs font-black">
                4
              </span>
              Жасыл — Дұрыс, Қызыл — Бұрыс!
            </h4>
            <p className="text-slate-400">
              10 секунд өткенде дұрыс жауап жағы <strong>жап-жасыл</strong> болып жанады, ал қате жағы <strong>қызыл</strong> болады!
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-3 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm transition-colors cursor-pointer"
        >
          Түсінікті, бастайық!
        </button>
      </div>
    </div>
  );
};
