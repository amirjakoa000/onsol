import React from 'react';
import { X, Sliders, Camera, RefreshCw, Eye } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  sensitivity: number;
  onSensitivityChange: (val: number) => void;
  isMirrored: boolean;
  onToggleMirrored: () => void;
  cameraEnabled: boolean;
  onToggleCamera: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  sensitivity,
  onSensitivityChange,
  isMirrored,
  onToggleMirrored,
  cameraEnabled,
  onToggleCamera,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
      <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 text-white space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-emerald-400" />
            <h3 className="text-lg font-bold font-['Unbounded']">Камера мен Тақта баптаулары</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-5 text-sm">
          {/* Sensitivity Slider */}
          <div className="space-y-2">
            <div className="flex justify-between font-bold">
              <span>Камераның қозғалыс сезімталдығы:</span>
              <span className="text-emerald-400">{sensitivity}%</span>
            </div>
            <input
              type="range"
              min="10"
              max="90"
              value={sensitivity}
              onChange={(e) => onSensitivityChange(Number(e.target.value))}
              className="w-full h-2 rounded-lg bg-slate-800 accent-emerald-500 cursor-pointer"
            />
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>Төмен (Тек үлкен топтар)</span>
              <span>Орташа</span>
              <span>Жоғары (Жылдам сезу)</span>
            </div>
          </div>

          {/* Mirror toggle */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80">
            <div>
              <div className="font-bold text-white flex items-center gap-2">
                <RefreshCw className="w-4 h-4 text-cyan-400" />
                Камераны айнадай көрсету (Mirror):
              </div>
              <div className="text-xs text-slate-400 mt-0.5">
                Оқушылар тақтаға қарағанда өздерін айнадағыдай көреді (ұсынылады)
              </div>
            </div>
            <button
              onClick={onToggleMirrored}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                isMirrored ? 'bg-emerald-500' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform absolute top-0.5 ${
                  isMirrored ? 'translate-x-6' : 'translate-x-0.5'
                }`}
              ></div>
            </button>
          </div>

          {/* Camera toggle */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80">
            <div>
              <div className="font-bold text-white flex items-center gap-2">
                <Camera className="w-4 h-4 text-emerald-400" />
                Веб-камера белсенділігі:
              </div>
              <div className="text-xs text-slate-400 mt-0.5">
                Егер сыныпта камера болмаса, тақтаны қолмен түртіп ойнауға болады
              </div>
            </div>
            <button
              onClick={onToggleCamera}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                cameraEnabled ? 'bg-emerald-500' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform absolute top-0.5 ${
                  cameraEnabled ? 'translate-x-6' : 'translate-x-0.5'
                }`}
              ></div>
            </button>
          </div>
        </div>

        <div className="pt-2">
          <button
            onClick={onClose}
            className="w-full py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm transition-colors cursor-pointer"
          >
            Дайын / Сақтау
          </button>
        </div>
      </div>
    </div>
  );
};
