import React from 'react';
import {
  Maximize,
  Minimize,
  Volume2,
  VolumeX,
  Camera,
  CameraOff,
  RotateCcw,
  Sliders,
  HelpCircle,
  Globe,
} from 'lucide-react';
import { Language, TRANSLATIONS } from '../utils/i18n';

interface NavbarProps {
  grade: string;
  topic: string;
  hasCamera: boolean;
  cameraEnabled: boolean;
  onToggleCamera: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onResetGame: () => void;
  onOpenSettings: () => void;
  onOpenHelp: () => void;
  currentStep?: string;
  language: Language;
  onLanguageChange: (lang: Language) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  grade,
  topic,
  cameraEnabled,
  onToggleCamera,
  isMuted,
  onToggleMute,
  isFullscreen,
  onToggleFullscreen,
  onResetGame,
  onOpenSettings,
  onOpenHelp,
  currentStep,
  language,
  onLanguageChange,
}) => {
  const t = TRANSLATIONS[language];

  return (
    <header className="w-full bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 py-2.5 flex items-center justify-between text-white z-40 select-none">
      {/* Brand & topic info */}
      <div className="flex items-center gap-3">
        <button
          onClick={onResetGame}
          className="flex items-center gap-2 group text-left cursor-pointer focus:outline-none"
          title="Басты мәзірге қайту"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-cyan-500 flex items-center justify-center font-black text-black text-lg shadow-lg shadow-teal-500/20 group-hover:scale-105 transition-transform">
            ⚡
          </div>
          <div>
            <div className="flex items-center gap-1.5 font-bold text-sm sm:text-base tracking-wide bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent font-times">
              {t.gameTitle}
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 uppercase font-sans tracking-wider font-semibold">
                {t.smartboardBadge}
              </span>
            </div>
            {topic && (
              <div className="text-xs text-slate-400 flex items-center gap-1.5 truncate max-w-[200px] sm:max-w-xs md:max-w-md font-times">
                <span className="text-emerald-400 font-semibold">{grade}</span>
                <span>•</span>
                <span className="truncate">{topic}</span>
              </div>
            )}
          </div>
        </button>
      </div>

      {/* Middle status if active */}
      {currentStep && (
        <div className="hidden md:flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700 text-xs font-medium text-slate-300 font-times">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>{currentStep}</span>
        </div>
      )}

      {/* Control buttons */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Language Switcher: Қазақша / Русский / English */}
        <div className="flex items-center bg-slate-800/90 border border-slate-700 rounded-xl p-0.5 shadow-inner">
          <Globe className="w-3.5 h-3.5 text-cyan-400 ml-1.5 mr-0.5 hidden xs:block" />
          {(['kk', 'ru', 'en'] as Language[]).map((lang) => {
            const isActive = language === lang;
            return (
              <button
                key={lang}
                onClick={() => onLanguageChange(lang)}
                className={`px-2 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-md font-black'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
                }`}
                title={lang === 'kk' ? 'Қазақ тілі' : lang === 'ru' ? 'Русский язык' : 'English'}
              >
                {lang.toUpperCase()}
              </button>
            );
          })}
        </div>

        {/* Help button */}
        <button
          onClick={onOpenHelp}
          className="p-2 sm:px-3 sm:py-1.5 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer font-times"
          title="Нұсқаулық"
        >
          <HelpCircle className="w-4 h-4 text-cyan-400" />
          <span className="hidden lg:inline">{language === 'kk' ? 'Нұсқаулық' : language === 'ru' ? 'Инструкция' : 'Help'}</span>
        </button>

        {/* Camera Toggle */}
        <button
          onClick={onToggleCamera}
          className={`p-2 sm:px-3 sm:py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer font-times ${
            cameraEnabled
              ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/25'
              : 'bg-rose-500/15 text-rose-300 border-rose-500/40 hover:bg-rose-500/25'
          }`}
          title={cameraEnabled ? t.cameraOff : t.cameraOn}
        >
          {cameraEnabled ? <Camera className="w-4 h-4" /> : <CameraOff className="w-4 h-4" />}
          <span className="hidden sm:inline">{cameraEnabled ? t.cameraOn : t.cameraOff}</span>
        </button>

        {/* Camera Calibration / Sensitivity */}
        <button
          onClick={onOpenSettings}
          className="p-2 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors cursor-pointer"
          title="Параметрлер"
        >
          <Sliders className="w-4 h-4 text-emerald-400" />
        </button>

        {/* Mute/Unmute */}
        <button
          onClick={onToggleMute}
          className="p-2 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors cursor-pointer"
          title={isMuted ? 'Дыбысты қосу' : 'Дыбысты өшіру'}
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
        </button>

        {/* Fullscreen Button */}
        <button
          onClick={onToggleFullscreen}
          className="p-2 sm:px-3 sm:py-1.5 rounded-lg bg-indigo-600/90 hover:bg-indigo-500 text-white border border-indigo-400/30 text-xs font-bold flex items-center gap-1.5 shadow-md shadow-indigo-600/20 transition-all cursor-pointer font-times"
          title={isFullscreen ? 'Шығу' : 'Толық экран'}
        >
          {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
          <span className="hidden sm:inline">{isFullscreen ? 'Шығу' : 'Толық тақта'}</span>
        </button>

        {/* Reset / Exit game */}
        <button
          onClick={onResetGame}
          className="p-2 rounded-lg bg-slate-800/90 hover:bg-rose-950/60 hover:text-rose-300 text-slate-400 border border-slate-700 transition-colors cursor-pointer"
          title="Басына оралу"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
