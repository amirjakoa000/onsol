import React, { useState } from 'react';
import {
  Sparkles,
  Play,
  Layers,
  Flame,
  Clock,
  Video,
  VideoOff,
  Edit3,
  FileText,
  BookOpen,
} from 'lucide-react';
import { GameQuestion, MotionStats } from '../types';
import { TOPIC_PRESETS, PRESET_QUESTIONS_BY_TOPIC, GRADE_OPTIONS, randomizeQuestions } from '../utils/presets';
import { Language, TRANSLATIONS } from '../utils/i18n';

interface LobbyProps {
  onStartGame: (
    questions: GameQuestion[],
    topic: string,
    grade: string,
    timerSeconds: number
  ) => void;
  isGenerating: boolean;
  onGenerateAI: (
    topic: string,
    grade: string,
    count: number,
    customText?: string
  ) => Promise<GameQuestion[] | null>;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  hasCamera: boolean;
  cameraEnabled: boolean;
  onToggleCamera: () => void;
  motionStats: MotionStats;
  onOpenQuestionEditor: (questions: GameQuestion[], onSave: (q: GameQuestion[]) => void) => void;
  language?: Language;
}

export const Lobby: React.FC<LobbyProps> = ({
  onStartGame,
  isGenerating,
  onGenerateAI,
  videoRef,
  hasCamera,
  cameraEnabled,
  onToggleCamera,
  motionStats,
  onOpenQuestionEditor,
  language = 'kk',
}) => {
  const t = TRANSLATIONS[language];
  const [activeTab, setActiveTab] = useState<'text' | 'preset'>('text'); // Басты назар пайдаланушының өз мәтініне беріледі!
  const [customText, setCustomText] = useState<string>('');
  const [selectedTopicPreset, setSelectedTopicPreset] = useState<string>('chemistry_water');
  const [customTopic, setCustomTopic] = useState<string>('');
  const [selectedGrade, setSelectedGrade] = useState<string>('5-сынып');
  const [questionCount, setQuestionCount] = useState<number>(10);
  const [timerSeconds, setTimerSeconds] = useState<number>(10);
  const [activeQuestions, setActiveQuestions] = useState<GameQuestion[]>(() =>
    randomizeQuestions(PRESET_QUESTIONS_BY_TOPIC['chemistry_water'] || [], 10)
  );

  const activeTopicTitle = customTopic.trim()
    ? customTopic
    : (TOPIC_PRESETS.find((p) => p.id === selectedTopicPreset)?.name || 'Берілген ақпарат');

  // Дайын пәнді басқанда
  const handleSelectPreset = (presetId: string) => {
    setSelectedTopicPreset(presetId);
    setCustomTopic('');
    const raw = PRESET_QUESTIONS_BY_TOPIC[presetId] || [];
    const randomized = randomizeQuestions(raw, questionCount);
    setActiveQuestions(randomized);
  };

  // Дайын сұрақтармен бірден бастау
  const handleStartInstantly = () => {
    const randomized = randomizeQuestions(activeQuestions, questionCount);
    onStartGame(randomized, activeTopicTitle, selectedGrade, timerSeconds);
  };

  // ЖИ арқылы генерация (Пайдаланушы берген нақты мәтін не тақырып бойынша)
  const handleGenerate = async () => {
    const topicToUse = customTopic.trim() || (activeTab === 'text' ? 'Мұғалімнің берген мәтіні' : activeTopicTitle);
    const questions = await onGenerateAI(topicToUse, selectedGrade, questionCount, customText.trim());
    if (questions && questions.length > 0) {
      const randomized = randomizeQuestions(questions, questionCount);
      setActiveQuestions(randomized);
      onStartGame(randomized, topicToUse, selectedGrade, timerSeconds);
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 py-6 md:py-8 space-y-6 font-times">
      {/* Hero Banner for Smartboard */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-800/40 p-6 md:p-8 shadow-2xl text-center">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-teal-500/10 via-transparent to-transparent pointer-events-none"></div>

        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-400/30 text-emerald-300 text-xs md:text-sm font-bold tracking-wide uppercase mb-3">
          <Sparkles className="w-4 h-4 text-emerald-400 animate-spin" />
          {t.gameSubtitle}
        </div>

        <h1 className="text-3xl sm:text-5xl md:text-6xl font-black tracking-tight text-white leading-tight font-times">
          {t.gameTitle}
        </h1>

        <p className="mt-3 text-slate-300 text-sm sm:text-base md:text-lg max-w-3xl mx-auto font-medium font-times">
          {t.heroDesc}
        </p>

        {/* 3 Quick Game Rules Badge */}
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-3xl mx-auto text-left font-times">
          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 font-black flex items-center justify-center shrink-0">
              1
            </div>
            <div>
              <div className="text-xs font-bold text-white uppercase tracking-wider">{t.rule1Title}</div>
              <div className="text-xs text-slate-400 mt-0.5">{t.rule1Desc}</div>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 font-black flex items-center justify-center shrink-0">
              2
            </div>
            <div>
              <div className="text-xs font-bold text-white uppercase tracking-wider">{t.rule2Title}</div>
              <div className="text-xs text-slate-400 mt-0.5">{t.rule2Desc}</div>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 font-black flex items-center justify-center shrink-0">
              3
            </div>
            <div>
              <div className="text-xs font-bold text-white uppercase tracking-wider">{t.rule3Title}</div>
              <div className="text-xs text-slate-400 mt-0.5">{t.rule3Desc}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 font-times">
        {/* Left Column: Topic, Grade & AI generation controls (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Step 1: Input custom text OR select preset */}
          <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 md:p-6 shadow-xl space-y-4">
            {/* Tabs for "Custom Text" vs "Preset subjects" */}
            <div className="flex items-center gap-2 p-1 bg-slate-950/80 border border-slate-800 rounded-2xl">
              <button
                onClick={() => setActiveTab('text')}
                className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  activeTab === 'text'
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-md font-black'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>{t.textPromptTabTitle}</span>
              </button>

              <button
                onClick={() => setActiveTab('preset')}
                className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  activeTab === 'preset'
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-md font-black'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <BookOpen className="w-4 h-4" />
                <span>{t.presetTabTitle}</span>
              </button>
            </div>

            {/* TAB 1: ПАЙДАЛАНУШЫНЫҢ ӨЗ МӘТІНІ МЕН АҚПАРАТЫ */}
            {activeTab === 'text' ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-bold text-white flex items-center gap-2">
                    <FileText className="w-4 h-4 text-emerald-400" />
                    <span>{t.textPromptLabel}</span>
                  </label>
                  {customText && (
                    <button
                      onClick={() => setCustomText('')}
                      className="text-xs px-2 py-0.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white border border-slate-700 cursor-pointer"
                    >
                      {t.clear}
                    </button>
                  )}
                </div>

                <div className="relative">
                  <textarea
                    rows={6}
                    value={customText}
                    onChange={(e) => setCustomText(e.target.value)}
                    placeholder={t.textPromptPlaceholder}
                    className="w-full p-4 rounded-2xl bg-slate-950/90 border-2 border-emerald-500/40 text-white placeholder-slate-500 text-sm md:text-base leading-relaxed focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:border-emerald-400 transition-all font-times shadow-inner resize-y"
                  />
                  {customText && (
                    <div className="absolute right-3 bottom-3 text-[11px] text-emerald-400 font-bold bg-slate-900/90 px-2 py-0.5 rounded-lg border border-emerald-500/30">
                      {customText.length} таңба
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 text-xs text-emerald-400/90 bg-emerald-500/10 p-3 rounded-xl border border-emerald-500/20">
                  <Sparkles className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>{t.textPromptHint}</span>
                </div>
              </div>
            ) : (
              /* TAB 2: ДАЙЫН ПӘНДЕР МЕН ҚЫСҚА ТАҚЫРЫП */
              <div className="space-y-3">
                <div className="relative">
                  <input
                    type="text"
                    value={customTopic}
                    onChange={(e) => setCustomTopic(e.target.value)}
                    placeholder={t.customTopicPlaceholder}
                    className="w-full px-4 py-3.5 rounded-2xl bg-slate-800/90 border border-slate-700 text-white placeholder-slate-500 text-sm md:text-base focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all font-times"
                  />
                  {customTopic && (
                    <button
                      onClick={() => setCustomTopic('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-xs px-2 py-1 rounded-lg bg-slate-700 text-slate-300 hover:text-white"
                    >
                      {t.clear}
                    </button>
                  )}
                </div>

                {/* Preset Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
                  {TOPIC_PRESETS.map((preset) => {
                    const isSelected = !customTopic && selectedTopicPreset === preset.id;
                    return (
                      <button
                        key={preset.id}
                        onClick={() => handleSelectPreset(preset.id)}
                        className={`p-3 rounded-2xl border text-left transition-all cursor-pointer relative overflow-hidden group ${
                          isSelected
                            ? 'bg-gradient-to-br from-emerald-950/60 to-slate-900 border-emerald-500/80 shadow-lg shadow-emerald-500/10 ring-1 ring-emerald-500/40'
                            : 'bg-slate-800/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800'
                        }`}
                      >
                        <div className="text-2xl mb-1.5">{preset.emoji}</div>
                        <div className="font-bold text-xs sm:text-sm text-white group-hover:text-emerald-300 line-clamp-1 font-times">
                          {preset.name}
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">{preset.grade}</div>
                        {isSelected && (
                          <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-emerald-400 animate-ping"></div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Step 2: Grade selection */}
          <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 md:p-6 shadow-xl space-y-3">
            <label className="text-base font-bold text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-cyan-400" />
              {t.step2Title}
            </label>

            <div className="flex flex-wrap gap-2">
              {GRADE_OPTIONS.map((grade) => {
                const isSelected = selectedGrade === grade;
                return (
                  <button
                    key={grade}
                    onClick={() => setSelectedGrade(grade)}
                    className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/25 scale-105'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700'
                    }`}
                  >
                    {grade}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 3: Game Parameters (Question count & 10s Timer) */}
          <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 md:p-6 shadow-xl grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-bold text-white flex items-center gap-2 mb-2">
                <Flame className="w-4 h-4 text-amber-400" />
                {t.step3Count}
              </label>
              <div className="flex gap-2">
                {[5, 7, 10].map((cnt) => (
                  <button
                    key={cnt}
                    onClick={() => {
                      setQuestionCount(cnt);
                      const baseQuestions = customTopic.trim()
                        ? activeQuestions
                        : (PRESET_QUESTIONS_BY_TOPIC[selectedTopicPreset] || activeQuestions);
                      setActiveQuestions(randomizeQuestions(baseQuestions, cnt));
                    }}
                    className={`flex-1 py-2.5 rounded-xl font-bold text-sm border transition-all cursor-pointer ${
                      questionCount === cnt
                        ? 'bg-amber-500 text-black border-amber-400 shadow-md shadow-amber-500/20'
                        : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {cnt} {t.questionsWord}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm font-bold text-white flex items-center gap-2 mb-2">
                <Clock className="w-4 h-4 text-emerald-400" />
                {t.step3Timer}
              </label>
              <div className="flex gap-2">
                {[10, 15, 20].map((sec) => (
                  <button
                    key={sec}
                    onClick={() => setTimerSeconds(sec)}
                    className={`flex-1 py-2.5 rounded-xl font-bold text-sm border transition-all cursor-pointer ${
                      timerSeconds === sec
                        ? 'bg-emerald-500 text-black border-emerald-400 shadow-md shadow-emerald-500/20'
                        : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {sec} {t.secondsWord}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Action Buttons: AI Start & Instant Start */}
          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            {/* AI Generator button */}
            <button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="flex-1 py-4 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-black text-base sm:text-lg flex items-center justify-center gap-2.5 shadow-xl shadow-teal-500/25 transition-all transform active:scale-98 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed font-times"
            >
              {isGenerating ? (
                <>
                  <div className="w-5 h-5 border-3 border-black border-t-transparent rounded-full animate-spin"></div>
                  <span>{t.btnGenerating}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 text-slate-950 animate-bounce" />
                  <span>
                    {activeTab === 'text' && customText.trim().length > 10
                      ? `${t.btnGenerateFromText} (${questionCount} ${t.questionsWord})`
                      : `${t.btnStartAI} (${questionCount} ${t.questionsWord})`}
                  </span>
                </>
              )}
            </button>

            {/* Instant Play with curated preset */}
            <button
              onClick={handleStartInstantly}
              disabled={isGenerating}
              className="py-4 px-6 rounded-2xl bg-slate-800 hover:bg-slate-750 text-white font-extrabold text-base border border-slate-700 flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer font-times"
              title="Дайын сұрақтармен бірден ойнау"
            >
              <Play className="w-5 h-5 text-emerald-400 fill-emerald-400" />
              <span>{t.btnStartInstant}</span>
            </button>
          </div>
        </div>

        {/* Right Column: Live Camera Split Preview & Calibration (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-white text-base font-times">
                <Video className="w-5 h-5 text-cyan-400" />
                <span>{t.cameraTestTitle}</span>
              </div>
              <button
                onClick={onToggleCamera}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border flex items-center gap-1.5 transition-colors cursor-pointer ${
                  cameraEnabled
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                }`}
              >
                {cameraEnabled ? <Video className="w-3.5 h-3.5" /> : <VideoOff className="w-3.5 h-3.5" />}
                <span>{cameraEnabled ? t.cameraOn : t.cameraOff}</span>
              </button>
            </div>

            {/* Live Camera View with Split Screen line */}
            <div className="relative aspect-[16/9] w-full rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 shadow-inner flex items-center justify-center">
              {cameraEnabled && hasCamera ? (
                <>
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover transform -scale-x-100"
                  />

                  {/* 50/50 Split guideline for testing */}
                  <div className="absolute inset-0 flex pointer-events-none">
                    <div className="flex-1 h-full border-r-2 border-dashed border-white/60 flex items-center justify-center">
                      <div className="px-3 py-1 rounded-xl bg-slate-950/80 border border-emerald-400/50 text-white font-black text-sm">
                        {t.sideA}
                      </div>
                    </div>
                    <div className="flex-1 h-full flex items-center justify-center">
                      <div className="px-3 py-1 rounded-xl bg-slate-950/80 border border-rose-500/50 text-white font-black text-sm">
                        {t.sideB}
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center p-6 text-slate-500 font-times">
                  <VideoOff className="w-10 h-10 mx-auto mb-2 text-slate-600" />
                  <p className="text-xs">{t.cameraDisabledHint}</p>
                  <p className="text-[11px] text-slate-600 mt-1">{t.cameraAltHint}</p>
                </div>
              )}
            </div>

            {/* Questions preview info */}
            <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-white font-times">
                  {t.selectedQuestions} <span className="text-emerald-400 font-black">{questionCount} {t.questionsWord}</span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5 font-times">
                  {t.randomizedHint}
                </div>
              </div>
              <button
                onClick={() => onOpenQuestionEditor(activeQuestions, setActiveQuestions)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer font-times"
              >
                <Edit3 className="w-3.5 h-3.5 text-cyan-400" />
                <span>{t.edit}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
