import React, { useEffect } from 'react';
import {
  Trophy,
  Award,
  Sparkles,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Home,
} from 'lucide-react';
import { RoundResult, GameQuestion } from '../types';
import confetti from 'canvas-confetti';
import { sound } from '../utils/audio';
import { Language, TRANSLATIONS } from '../utils/i18n';

interface ResultModalProps {
  score: number;
  results: RoundResult[];
  questions: GameQuestion[];
  topic: string;
  grade: string;
  onPlayAgain: () => void;
  onBackToLobby: () => void;
  language?: Language;
}

export const ResultModal: React.FC<ResultModalProps> = ({
  results,
  questions,
  topic,
  grade,
  onPlayAgain,
  onBackToLobby,
  language = 'kk',
}) => {
  const t = TRANSLATIONS[language];
  const totalQuestions = questions.length;
  const correctCount = results.filter((r) => r.isClassCorrect).length;
  const accuracy = Math.round((correctCount / Math.max(1, totalQuestions)) * 100);

  useEffect(() => {
    sound.playCheer();
    const end = Date.now() + 2.5 * 1000;
    const colors = ['#10b981', '#06b6d4', '#f59e0b', '#ec4899'];

    (function frame() {
      confetti({
        particleCount: 4,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: colors,
      });
      confetti({
        particleCount: 4,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: colors,
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    })();
  }, []);

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-8 animate-in zoom-in-95 duration-300 font-times">
      <div className="rounded-3xl bg-slate-900/95 border border-slate-800 p-6 md:p-10 shadow-2xl backdrop-blur-xl text-center space-y-6">
        {/* Trophy icon */}
        <div className="relative inline-flex items-center justify-center">
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-300 flex items-center justify-center text-black shadow-xl shadow-amber-500/30 animate-bounce">
            <Trophy className="w-12 h-12 sm:w-14 sm:h-14 fill-current" />
          </div>
          <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-emerald-500 border-2 border-slate-900 flex items-center justify-center text-white">
            <Sparkles className="w-4 h-4 fill-white" />
          </div>
        </div>

        <div>
          <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight font-times">
            {t.resultsTitle}
          </h2>
          <p className="text-slate-400 text-sm sm:text-base mt-2 font-times">
            {t.resultsSubtitle} • <span className="text-emerald-400 font-bold">{topic}</span> ({grade})
          </p>
        </div>

        {/* Big Score Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl mx-auto pt-2">
          {/* Correct count */}
          <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 flex flex-col items-center">
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 uppercase">
              <CheckCircle2 className="w-4 h-4" />
              <span>{t.correctCountLabel}</span>
            </div>
            <div className="text-4xl sm:text-5xl font-black text-emerald-300 mt-1">
              {correctCount} / {totalQuestions}
            </div>
          </div>

          {/* Accuracy percentage */}
          <div className="p-4 rounded-2xl bg-cyan-950/40 border border-cyan-500/40 flex flex-col items-center">
            <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400 uppercase">
              <Award className="w-4 h-4" />
              <span>{t.accuracy}</span>
            </div>
            <div className="text-4xl sm:text-5xl font-black text-cyan-300 mt-1">
              {accuracy}%
            </div>
          </div>

          {/* Wrong count */}
          <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-500/40 flex flex-col items-center">
            <div className="flex items-center gap-1.5 text-xs font-bold text-rose-400 uppercase">
              <XCircle className="w-4 h-4" />
              <span>{t.wrongCountLabel}</span>
            </div>
            <div className="text-4xl sm:text-5xl font-black text-rose-300 mt-1">
              {totalQuestions - correctCount}
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
          <button
            onClick={onPlayAgain}
            className="py-4 px-8 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-black text-base sm:text-lg flex items-center justify-center gap-2.5 shadow-xl shadow-teal-500/25 transition-all transform active:scale-95 cursor-pointer font-times"
          >
            <RotateCcw className="w-5 h-5" />
            <span>{t.playAgain}</span>
          </button>

          <button
            onClick={onBackToLobby}
            className="py-4 px-8 rounded-2xl bg-slate-800 hover:bg-slate-750 text-white font-extrabold text-base border border-slate-700 flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer font-times"
          >
            <Home className="w-5 h-5 text-slate-400" />
            <span>{t.backToLobby}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
