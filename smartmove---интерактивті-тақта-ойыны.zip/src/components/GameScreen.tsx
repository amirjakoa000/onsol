import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Volume2,
  VolumeX,
  Camera,
  CameraOff,
  Maximize,
  Minimize,
  Home,
  ChevronRight,
  Flame,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { GameQuestion, MotionStats, RoundResult } from '../types';
import { sound } from '../utils/audio';
import { Language, TRANSLATIONS } from '../utils/i18n';

interface GameScreenProps {
  questions: GameQuestion[];
  currentIndex: number;
  timerDuration: number;
  topicTitle: string;
  categoryName?: string;
  motionStats: MotionStats;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  cameraEnabled: boolean;
  onToggleCamera: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onFinishGame: (results: RoundResult[], score: number) => void;
  onExitGame: () => void;
  freezeCamera: () => void;
  unfreezeCamera: () => void;
  manualSetSide: (side: 'left' | 'right') => void;
  onNextQuestion: () => void;
  language?: Language;
}

export const GameScreen: React.FC<GameScreenProps> = ({
  questions,
  currentIndex,
  timerDuration,
  topicTitle,
  categoryName,
  motionStats,
  videoRef,
  cameraEnabled,
  onToggleCamera,
  isMuted,
  onToggleMute,
  isFullscreen,
  onToggleFullscreen,
  onFinishGame,
  onExitGame,
  freezeCamera,
  unfreezeCamera,
  manualSetSide,
  onNextQuestion,
  language = 'kk',
}) => {
  const t = TRANSLATIONS[language];
  const currentQuestion = questions[currentIndex] || questions[0];
  const totalQuestions = questions.length;

  const [timeLeft, setTimeLeft] = useState<number>(timerDuration);
  const [isRevealed, setIsRevealed] = useState<boolean>(false);
  const [results, setResults] = useState<RoundResult[]>([]);
  const [correctCount, setCorrectCount] = useState<number>(0);
  const [wrongCount, setWrongCount] = useState<number>(0);
  const [autoNextCountdown, setAutoNextCountdown] = useState<number>(3);

  // Keep fresh references for callbacks and listeners
  const isRevealedRef = useRef<boolean>(false);
  isRevealedRef.current = isRevealed;

  const motionStatsRef = useRef<MotionStats>(motionStats);
  motionStatsRef.current = motionStats;

  // Reset when question index changes
  useEffect(() => {
    setTimeLeft(timerDuration);
    setIsRevealed(false);
    setAutoNextCountdown(3);
    unfreezeCamera();
  }, [currentIndex, timerDuration, unfreezeCamera]);

  // Reveal answer round logic
  const handleRevealWithChoice = useCallback((chosenSideOverride?: 'left' | 'right') => {
    if (isRevealedRef.current) return;
    setIsRevealed(true);
    freezeCamera();

    try {
      sound.playTimesUp();
    } catch {}

    const stats = motionStatsRef.current;
    const finalLeft = stats.leftRatio;
    const finalRight = stats.rightRatio;
    const correctSide = currentQuestion.correctSide;

    let dominantSide: 'left' | 'right' | 'equal' | 'none' = chosenSideOverride || stats.dominantSide;
    if (!chosenSideOverride) {
      if (finalLeft > finalRight + 0.08) dominantSide = 'left';
      else if (finalRight > finalLeft + 0.08) dominantSide = 'right';
    }

    const isClassCorrect =
      (correctSide === 'left' && dominantSide === 'left') ||
      (correctSide === 'right' && dominantSide === 'right');

    const leftPercent = Math.round(finalLeft * 100);
    const rightPercent = Math.round(finalRight * 100);

    const roundRes: RoundResult = {
      questionId: currentQuestion.id,
      correctSide,
      dominantSide,
      isClassCorrect,
      leftPercentage: leftPercent,
      rightPercentage: rightPercent,
    };

    setResults((prev) => [...prev, roundRes]);

    if (isClassCorrect) {
      setCorrectCount((prev) => prev + 1);
      setTimeout(() => {
        try {
          sound.playCorrect();
        } catch {}
        try {
          confetti({
            particleCount: 80,
            spread: 75,
            origin: {
              x: correctSide === 'left' ? 0.35 : 0.65,
              y: 0.55,
            },
          });
        } catch {}
      }, 200);
    } else {
      setWrongCount((prev) => prev + 1);
      setTimeout(() => {
        try {
          sound.playWrong();
        } catch {}
      }, 200);
    }
  }, [freezeCamera, currentQuestion]);

  // 1-second countdown timer for answering (10s)
  useEffect(() => {
    if (isRevealed) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          // Деферлейміз (setTimeout) - басты render циклінде басқа компоненттің күйін жаңарту қатесін болдырмау үшін
          setTimeout(() => {
            handleRevealWithChoice();
          }, 0);
          return 0;
        }

        const next = prev - 1;
        try {
          if (next <= 3 && next > 0) {
            sound.playUrgentTick();
          } else {
            sound.playTick();
          }
        } catch {}
        return next;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isRevealed, handleRevealWithChoice]);

  // Next Question logic (setTimeout арқылы шақыру қауіпсіздігі)
  const handleNext = useCallback(() => {
    setTimeout(() => {
      if (currentIndex + 1 >= totalQuestions) {
        onFinishGame(results, correctCount * 100);
      } else {
        onNextQuestion();
      }
    }, 0);
  }, [currentIndex, totalQuestions, results, correctCount, onFinishGame, onNextQuestion]);

  // АВТОМАТТЫ ТҮРДЕ КЕЛЕСІ СҰРАҚҚА ӨТУ (3 секундтан кейін)
  useEffect(() => {
    if (!isRevealed) return;

    setAutoNextCountdown(3);
    const autoTimer = setInterval(() => {
      setAutoNextCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(autoTimer);
          handleNext();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(autoTimer);
  }, [isRevealed, handleNext]);

  // Keyboard navigation & smartboard touch override
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        manualSetSide('left');
        if (!isRevealedRef.current) handleRevealWithChoice('left');
      } else if (e.key === 'ArrowRight') {
        manualSetSide('right');
        if (!isRevealedRef.current) handleRevealWithChoice('right');
      } else if (e.key === ' ' || e.key === 'Spacebar' || e.key === 'Enter') {
        e.preventDefault();
        if (!isRevealedRef.current) {
          handleRevealWithChoice();
        } else {
          handleNext();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleRevealWithChoice, manualSetSide, handleNext]);

  const isLeftCorrect = currentQuestion.correctSide === 'left';
  const isRightCorrect = currentQuestion.correctSide === 'right';
  const displayCategory = categoryName || currentQuestion.category || topicTitle;

  return (
    <div className="relative w-full h-screen overflow-hidden bg-slate-950 select-none flex flex-col justify-between font-times">
      {/* BACKGROUND WEBCAM / CLASSROOM CAMERA */}
      <div className="absolute inset-0 w-full h-full overflow-hidden">
        {cameraEnabled ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover transform -scale-x-100"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950" />
        )}

        {/* 10s ойлану уақытында мөлдір, жауап шыққанда дұрыс жағы ЖАСЫЛ, бұрыс жағы ҚЫЗЫЛ жанады */}
        <div className="absolute inset-0 flex pointer-events-none transition-colors duration-500">
          {/* LEFT HALF TINT */}
          <div
            className={`flex-1 h-full border-r border-white/20 transition-all duration-500 ${
              !isRevealed
                ? 'bg-transparent'
                : isLeftCorrect
                ? 'bg-emerald-600/40 shadow-[inset_0_0_80px_rgba(52,211,153,0.7)]'
                : 'bg-rose-700/40 shadow-[inset_0_0_80px_rgba(244,63,94,0.7)]'
            }`}
          />

          {/* RIGHT HALF TINT */}
          <div
            className={`flex-1 h-full transition-all duration-500 ${
              !isRevealed
                ? 'bg-transparent'
                : isRightCorrect
                ? 'bg-emerald-600/40 shadow-[inset_0_0_80px_rgba(52,211,153,0.7)]'
                : 'bg-rose-700/40 shadow-[inset_0_0_80px_rgba(244,63,94,0.7)]'
            }`}
          />
        </div>
      </div>

      {/* TOP HEADER: SCORES, TIMER, CONTROL BUTTONS */}
      <header className="relative z-30 w-full px-6 py-4 flex items-center justify-between">
        {/* LEFT: SCORES (Green circle for Correct, Red for Wrong) */}
        <div className="flex items-center gap-3">
          {/* GREEN CIRCLE SCORE */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-slate-950/80 border border-emerald-500/40 backdrop-blur-md shadow-lg">
            <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-white font-black text-sm shadow-[0_0_12px_#10b981]">
              <CheckCircle2 className="w-5 h-5 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase font-bold text-emerald-300 tracking-wider">
                {t.correctCountLabel}
              </span>
              <span className="text-xl font-black text-emerald-400 leading-tight">
                {correctCount}
              </span>
            </div>
          </div>

          {/* RED BADGE: WRONG */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-slate-950/80 border border-rose-500/40 backdrop-blur-md shadow-lg">
            <div className="w-8 h-8 rounded-full bg-rose-500 flex items-center justify-center text-white font-black text-sm shadow-[0_0_12px_#f43f5e]">
              <XCircle className="w-5 h-5 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase font-bold text-rose-300 tracking-wider">
                {t.wrongCountLabel}
              </span>
              <span className="text-xl font-black text-rose-400 leading-tight">
                {wrongCount}
              </span>
            </div>
          </div>
        </div>

        {/* CENTER: MASSIVE GLOWING 10-SEC COUNTDOWN TIMER */}
        <div className="flex flex-col items-center">
          <div
            className={`w-20 h-20 sm:w-24 sm:h-24 rounded-full flex flex-col items-center justify-center font-black transition-all shadow-2xl border-4 ${
              isRevealed
                ? 'bg-slate-900/90 border-slate-700 text-slate-400'
                : timeLeft <= 3
                ? 'bg-rose-600/90 border-white text-white scale-110 shadow-[0_0_35px_#f43f5e] animate-pulse'
                : 'bg-emerald-500/90 border-white text-white shadow-[0_0_35px_#10b981]'
            }`}
          >
            <span className="text-3xl sm:text-4xl leading-none">
              {isRevealed ? '✓' : timeLeft}
            </span>
            <span className="text-[9px] uppercase tracking-wider font-extrabold mt-0.5 opacity-90">
              {isRevealed ? 'ТАҢДАЛДЫ' : t.timeRemaining}
            </span>
          </div>
        </div>

        {/* RIGHT: QUESTION COUNTER & QUICK CONTROL BUTTONS */}
        <div className="flex items-center gap-3">
          {/* Question counter pill */}
          <div className="px-3.5 py-1.5 rounded-2xl bg-slate-950/80 border border-slate-700 text-xs sm:text-sm font-bold text-slate-200 backdrop-blur-md shadow-lg flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-amber-400" />
            <span>
              {currentIndex + 1} / {totalQuestions}
            </span>
          </div>

          {/* Quick controls box */}
          <div className="flex items-center gap-1 bg-slate-950/80 border border-slate-800 rounded-2xl p-1 backdrop-blur-md shadow-lg">
            {/* Audio Toggle */}
            <button
              onClick={onToggleMute}
              className="p-2 sm:p-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title={isMuted ? 'Дыбысты қосу' : 'Дыбысты өшіру'}
            >
              {isMuted ? <VolumeX className="w-4 h-4 sm:w-5 sm:h-5 text-rose-400" /> : <Volume2 className="w-4 h-4 sm:w-5 sm:h-5" />}
            </button>

            {/* Camera Toggle */}
            <button
              onClick={onToggleCamera}
              className="p-2 sm:p-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title={cameraEnabled ? 'Камераны өшіру' : 'Камераны қосу'}
            >
              {cameraEnabled ? <Camera className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-400" /> : <CameraOff className="w-4 h-4 sm:w-5 sm:h-5 text-rose-400" />}
            </button>

            {/* Fullscreen Button */}
            <button
              onClick={onToggleFullscreen}
              className="p-2 sm:p-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title={isFullscreen ? 'Толық экраннан шығу' : 'Толық экранға ашу'}
            >
              {isFullscreen ? <Minimize className="w-4 h-4 sm:w-5 sm:h-5" /> : <Maximize className="w-4 h-4 sm:w-5 sm:h-5" />}
            </button>

            {/* Home / Exit Button */}
            <button
              onClick={onExitGame}
              className="p-2 sm:p-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-rose-950/60 transition-colors cursor-pointer"
              title="Басты мәзірге қайту"
            >
              <Home className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* CENTER AREA: QUESTION TEXT & REVEALED BADGE */}
      <div className="relative z-30 flex-1 flex flex-col items-center justify-center px-4 max-w-5xl mx-auto text-center pointer-events-none">
        {/* Category tag */}
        <div className="mb-3 inline-flex items-center px-3.5 py-1 rounded-full bg-slate-950/70 border border-white/20 text-emerald-300 text-xs sm:text-sm font-bold uppercase tracking-wider backdrop-blur-md">
          {displayCategory}
        </div>

        {/* HUGE QUESTION TEXT: Clean white, bold, prominent drop shadow in Times New Roman */}
        <h1 className="text-2xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-white leading-tight tracking-tight drop-shadow-[0_4px_12px_rgba(0,0,0,0.95)] max-w-4xl font-times">
          {currentQuestion.question}
        </h1>

        {/* CENTER POPUP: ДҰРЫС ЖАУАП [A] немесе [B] және АВТО-ӨТУ ТАЙМЕРІ */}
        {isRevealed && (
          <div className="mt-6 md:mt-8 p-4 md:p-6 rounded-3xl bg-slate-950/95 border-3 border-emerald-400 shadow-[0_0_50px_rgba(52,211,153,0.7)] backdrop-blur-xl animate-in zoom-in-90 duration-300 pointer-events-auto flex flex-col items-center">
            <span className="text-xs sm:text-sm md:text-base font-extrabold uppercase tracking-widest text-emerald-300 mb-2 font-times">
              {t.correctBadge}
            </span>

            {/* Glowing Center Answer Letter: Дұрыс жауап әрқашан ЖАСЫЛ */}
            <div className="relative flex items-center justify-center my-1">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl flex items-center justify-center text-3xl sm:text-4xl font-black text-white shadow-2xl bg-emerald-500 shadow-[0_0_30px_#10b981]">
                {isLeftCorrect ? 'A' : 'B'}
              </div>
            </div>

            {/* Explanation */}
            <p className="mt-2 text-xs sm:text-sm text-slate-300 max-w-md font-times">
              {currentQuestion.explanation}
            </p>

            {/* Автоматты түрде келесі сұраққа өту индикаторы (3 сек) */}
            <div className="mt-3 flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-bold font-times">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span>{t.nextQuestionIn} {autoNextCountdown} {t.secondsWord}</span>
            </div>

            {/* Қолмен де бірден басуға болатын батырма */}
            <button
              onClick={handleNext}
              className="mt-3 px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm sm:text-base flex items-center gap-1.5 shadow-lg shadow-emerald-500/30 cursor-pointer transition-all transform active:scale-95 font-times"
            >
              <span>{currentIndex + 1 >= totalQuestions ? t.resultsTitle : t.nextQuestionBtn}</span>
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>

      {/* BOTTOM SECTION: TWO HUGE PILL ANSWER BUTTONS */}
      <div className="relative z-30 w-full px-6 md:px-10 pb-8 pt-2">
        <div className="grid grid-cols-2 gap-6 md:gap-10 max-w-7xl mx-auto">
          {/* LEFT OPTION PILL: [A] */}
          <button
            onClick={() => {
              manualSetSide('left');
              if (!isRevealed) handleRevealWithChoice('left');
            }}
            className={`group w-full p-2.5 sm:p-3.5 md:p-4 rounded-3xl md:rounded-[36px] border-3 md:border-4 flex items-center justify-start gap-4 transition-all duration-300 transform active:scale-98 cursor-pointer backdrop-blur-md shadow-2xl ${
              !isRevealed
                ? 'bg-slate-900/80 hover:bg-slate-800/90 border-slate-600/80 shadow-[0_0_15px_rgba(0,0,0,0.5)]'
                : isLeftCorrect
                ? 'bg-emerald-500/95 border-white ring-6 ring-emerald-400/60 shadow-[0_0_45px_rgba(52,211,153,1)] scale-102'
                : 'bg-rose-950/70 border-rose-600 opacity-70'
            }`}
          >
            {/* Badge with white letter "A" */}
            <div
              className={`w-14 h-14 sm:w-16 sm:h-16 md:w-20 md:h-20 rounded-2xl md:rounded-3xl flex items-center justify-center text-white text-2xl sm:text-3xl md:text-4xl font-black font-times shadow-xl shrink-0 transition-colors ${
                !isRevealed
                  ? 'bg-slate-800 group-hover:bg-slate-700 border border-slate-600'
                  : isLeftCorrect
                  ? 'bg-emerald-600 text-white'
                  : 'bg-rose-800 text-white'
              }`}
            >
              A
            </div>

            {/* Answer Text in Times New Roman */}
            <div className="text-left min-w-0 pr-2">
              <span className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-extrabold text-white tracking-tight drop-shadow font-times line-clamp-2">
                {currentQuestion.leftOption}
              </span>
            </div>
          </button>

          {/* RIGHT OPTION PILL: [B] */}
          <button
            onClick={() => {
              manualSetSide('right');
              if (!isRevealed) handleRevealWithChoice('right');
            }}
            className={`group w-full p-2.5 sm:p-3.5 md:p-4 rounded-3xl md:rounded-[36px] border-3 md:border-4 flex items-center justify-end gap-4 transition-all duration-300 transform active:scale-98 cursor-pointer backdrop-blur-md shadow-2xl ${
              !isRevealed
                ? 'bg-slate-900/80 hover:bg-slate-800/90 border-slate-600/80 shadow-[0_0_15px_rgba(0,0,0,0.5)]'
                : isRightCorrect
                ? 'bg-emerald-500/95 border-white ring-6 ring-emerald-400/60 shadow-[0_0_45px_rgba(52,211,153,1)] scale-102'
                : 'bg-rose-950/70 border-rose-600 opacity-70'
            }`}
          >
            {/* Answer Text in Times New Roman */}
            <div className="text-right min-w-0 pl-2">
              <span className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-extrabold text-white tracking-tight drop-shadow font-times line-clamp-2">
                {currentQuestion.rightOption}
              </span>
            </div>

            {/* Badge with white letter "B" */}
            <div
              className={`w-14 h-14 sm:w-16 sm:h-16 md:w-20 md:h-20 rounded-2xl md:rounded-3xl flex items-center justify-center text-white text-2xl sm:text-3xl md:text-4xl font-black font-times shadow-xl shrink-0 transition-colors ${
                !isRevealed
                  ? 'bg-slate-800 group-hover:bg-slate-700 border border-slate-600'
                  : isRightCorrect
                  ? 'bg-emerald-600 text-white'
                  : 'bg-rose-800 text-white'
              }`}
            >
              B
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
