import React, { useState } from 'react';
import { X, Plus, Trash2, Edit3, Check, Save } from 'lucide-react';
import { GameQuestion } from '../types';

interface QuestionEditorModalProps {
  questions: GameQuestion[];
  isOpen: boolean;
  onClose: () => void;
  onSave: (questions: GameQuestion[]) => void;
}

export const QuestionEditorModal: React.FC<QuestionEditorModalProps> = ({
  questions,
  isOpen,
  onClose,
  onSave,
}) => {
  const [list, setList] = useState<GameQuestion[]>(questions);

  if (!isOpen) return null;

  const handleAddQuestion = () => {
    const newQ: GameQuestion = {
      id: `custom_${Date.now()}`,
      question: 'Жаңа сұрақтың мәтінін осында жазыңыз?',
      leftOption: 'Сол жақ нұсқасы',
      rightOption: 'Оң жақ нұсқасы',
      correctSide: 'left',
      explanation: 'Бұл жерде сұрақтың қысқаша дұрыс түсіндірмесі тұрады.',
      funFact: 'Қызықты қосымша факт.',
    };
    setList([...list, newQ]);
  };

  const handleUpdate = (idx: number, field: keyof GameQuestion, value: string) => {
    const updated = [...list];
    updated[idx] = { ...updated[idx], [field]: value };
    setList(updated);
  };

  const handleDelete = (idx: number) => {
    if (list.length <= 1) {
      alert('Кем дегенде 1 сұрақ қалуы керек!');
      return;
    }
    setList(list.filter((_, i) => i !== idx));
  };

  const handleSaveAndClose = () => {
    onSave(list);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
      <div className="w-full max-w-4xl max-h-[90vh] flex flex-col rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden text-white">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold font-['Unbounded'] text-white">
              Сұрақтар банкі және өңдеу
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Сұрақтарды өңдеңіз, жаңасын қосыңыз немесе дұрыс жағын таңдаңыз
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {list.map((q, idx) => (
            <div
              key={q.id}
              className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/80 space-y-3"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-black px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300">
                  #{idx + 1} Сұрақ
                </span>
                <button
                  onClick={() => handleDelete(idx)}
                  className="p-1.5 text-rose-400 hover:bg-rose-950/50 rounded-lg transition-colors cursor-pointer"
                  title="Жою"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Question text */}
              <div>
                <label className="text-[11px] font-bold text-slate-400 uppercase">Сұрақ:</label>
                <input
                  type="text"
                  value={q.question}
                  onChange={(e) => handleUpdate(idx, 'question', e.target.value)}
                  className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm font-semibold text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* 2 options */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Left option */}
                <div
                  className={`p-3 rounded-xl border transition-all ${
                    q.correctSide === 'left'
                      ? 'border-emerald-500 bg-emerald-950/30'
                      : 'border-slate-700 bg-slate-900'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-cyan-400">👈 СОЛ ЖАҚ (Нұсқа А)</span>
                    <button
                      type="button"
                      onClick={() => handleUpdate(idx, 'correctSide', 'left')}
                      className={`text-[11px] px-2 py-0.5 rounded font-bold cursor-pointer ${
                        q.correctSide === 'left'
                          ? 'bg-emerald-500 text-black'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {q.correctSide === 'left' ? '✓ Дұрыс жауап' : 'Дұрыс ету'}
                    </button>
                  </div>
                  <input
                    type="text"
                    value={q.leftOption}
                    onChange={(e) => handleUpdate(idx, 'leftOption', e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs font-semibold text-white focus:outline-none"
                  />
                </div>

                {/* Right option */}
                <div
                  className={`p-3 rounded-xl border transition-all ${
                    q.correctSide === 'right'
                      ? 'border-emerald-500 bg-emerald-950/30'
                      : 'border-slate-700 bg-slate-900'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-amber-400">ОҢ ЖАҚ (Нұсқа В) 👉</span>
                    <button
                      type="button"
                      onClick={() => handleUpdate(idx, 'correctSide', 'right')}
                      className={`text-[11px] px-2 py-0.5 rounded font-bold cursor-pointer ${
                        q.correctSide === 'right'
                          ? 'bg-emerald-500 text-black'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {q.correctSide === 'right' ? '✓ Дұрыс жауап' : 'Дұрыс ету'}
                    </button>
                  </div>
                  <input
                    type="text"
                    value={q.rightOption}
                    onChange={(e) => handleUpdate(idx, 'rightOption', e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs font-semibold text-white focus:outline-none"
                  />
                </div>
              </div>

              {/* Explanation */}
              <div>
                <label className="text-[11px] font-bold text-slate-400 uppercase">
                  Түсіндірме:
                </label>
                <input
                  type="text"
                  value={q.explanation}
                  onChange={(e) => handleUpdate(idx, 'explanation', e.target.value)}
                  className="w-full mt-1 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 flex items-center justify-between bg-slate-950/50">
          <button
            onClick={handleAddQuestion}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs flex items-center gap-2 border border-slate-700 cursor-pointer"
          >
            <Plus className="w-4 h-4 text-emerald-400" />
            <span>Жаңа сұрақ қосу</span>
          </button>

          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold cursor-pointer"
            >
              Болдырмау
            </button>
            <button
              onClick={handleSaveAndClose}
              className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/20 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Сақтау ({list.length} сұрақ)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
