import React, { useState, useEffect } from 'react';
import { GameQuestion, GameStatus, RoundResult } from './types';
import { Navbar } from './components/Navbar';
import { Lobby } from './components/Lobby';
import { GameScreen } from './components/GameScreen';
import { ResultModal } from './components/ResultModal';
import { QuestionEditorModal } from './components/QuestionEditorModal';
import { SettingsModal } from './components/SettingsModal';
import { HelpModal } from './components/HelpModal';
import { useCameraMotion } from './hooks/useCameraMotion';
import { PRESET_QUESTIONS_BY_TOPIC, randomizeQuestions } from './utils/presets';
import { sound } from './utils/audio';
import { Language } from './utils/i18n';

export default function App() {
  const [language, setLanguage] = useState<Language>('kk');
  const [status, setStatus] = useState<GameStatus>('setup');
  const [activeQuestions, setActiveQuestions] = useState<GameQuestion[]>(() =>
    randomizeQuestions(PRESET_QUESTIONS_BY_TOPIC['chemistry_water'] || [], 10)
  );
  const [currentTopic, setCurrentTopic] = useState<string>('Судың қасиеттері мен Химия');
  const [currentGrade, setCurrentGrade] = useState<string>('5-сынып');
  const [timerDuration, setTimerDuration] = useState<number>(10);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);

  // Settings
  const [cameraEnabled, setCameraEnabled] = useState<boolean>(true);
  const [cameraSensitivity, setCameraSensitivity] = useState<number>(45);
  const [isMirrored, setIsMirrored] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Modals
  const [isEditorOpen, setIsEditorOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isHelpOpen, setIsHelpOpen] = useState<boolean>(false);
  const [isGeneratingAI, setIsGeneratingAI] = useState<boolean>(false);

  // Game results
  const [finalScore, setFinalScore] = useState<number>(0);
  const [gameResults, setGameResults] = useState<RoundResult[]>([]);

  // Camera hook
  const {
    videoRef,
    hasCamera,
    cameraError,
    stats: motionStats,
    freezeStats,
    unfreezeStats,
    manualSetSide,
  } = useCameraMotion({
    enabled: cameraEnabled,
    sensitivity: cameraSensitivity,
    isMirrored,
  });

  // Fullscreen listener
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch((err) => {
        console.warn('Fullscreen request error:', err);
      });
    } else {
      document.exitFullscreen().catch((err) => {
        console.warn('Exit fullscreen error:', err);
      });
    }
  };

  const toggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    sound.setMuted(next);
  };

  // AI Question Generation: customText (мұғалімнің өз ақпараты/мәтіні) берілсе, ЖИ соның ішінен ғана сұрақ құрастырады
  const handleGenerateAI = async (
    topic: string,
    grade: string,
    count: number,
    customText?: string
  ): Promise<GameQuestion[] | null> => {
    try {
      setIsGeneratingAI(true);
      const res = await fetch('/api/generate-questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic, grade, count, language, customText: customText || '' }),
      });

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }

      const data = await res.json();
      if (data.questions && data.questions.length > 0) {
        return randomizeQuestions(data.questions, count);
      }
      return null;
    } catch (err) {
      console.warn('AI generation network error, using smart topic fallback:', err);
      const clean = topic.toLowerCase();
      let sourceQuestions = PRESET_QUESTIONS_BY_TOPIC['chemistry_water'];
      if (clean.includes('су') || clean.includes('вод') || clean.includes('water') || clean.includes('хим') || clean.includes('chem')) {
        sourceQuestions = PRESET_QUESTIONS_BY_TOPIC['chemistry_water'];
      } else if (clean.includes('физик') || clean.includes('ньютон') || clean.includes('phys')) {
        sourceQuestions = PRESET_QUESTIONS_BY_TOPIC['physics_science'];
      } else if (clean.includes('абай')) {
        sourceQuestions = PRESET_QUESTIONS_BY_TOPIC['abai_literature'];
      } else if (clean.includes('ғарыш') || clean.includes('космос') || clean.includes('space')) {
        sourceQuestions = PRESET_QUESTIONS_BY_TOPIC['space_science'];
      } else if (clean.includes('информ') || clean.includes('жи') || clean.includes('ai') || clean.includes('комп')) {
        sourceQuestions = PRESET_QUESTIONS_BY_TOPIC['informatics_ai'];
      }
      return randomizeQuestions(sourceQuestions, count);
    } finally {
      setIsGeneratingAI(false);
    }
  };

  // Start game handler
  const handleStartGame = (
    questions: GameQuestion[],
    topic: string,
    grade: string,
    duration: number
  ) => {
    if (!questions || questions.length === 0) {
      alert('Сұрақтар табылмады. Қайта көріңіз.');
      return;
    }
    const randomized = randomizeQuestions(questions, questions.length);
    setActiveQuestions(randomized);
    setCurrentTopic(topic);
    setCurrentGrade(grade);
    setTimerDuration(duration);
    setCurrentQuestionIndex(0);
    setGameResults([]);
    setFinalScore(0);
    setStatus('playing');
  };

  // Finish game handler
  const handleFinishGame = (results: RoundResult[], score: number) => {
    setGameResults(results);
    setFinalScore(score);
    setStatus('finished');
  };

  // Reset / Return to lobby
  const handleResetGame = () => {
    setStatus('setup');
    setCurrentQuestionIndex(0);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-white font-times">
      {/* Top Navbar only on setup and finished screens */}
      {status !== 'playing' && (
        <Navbar
          grade={currentGrade}
          topic={currentTopic}
          hasCamera={hasCamera}
          cameraEnabled={cameraEnabled}
          onToggleCamera={() => setCameraEnabled((c) => !c)}
          isMuted={isMuted}
          onToggleMute={toggleMute}
          isFullscreen={isFullscreen}
          onToggleFullscreen={toggleFullscreen}
          onResetGame={handleResetGame}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenHelp={() => setIsHelpOpen(true)}
          language={language}
          onLanguageChange={setLanguage}
        />
      )}

      {/* Main View Area */}
      <main className="flex-1 flex flex-col justify-center">
        {status === 'setup' && (
          <Lobby
            onStartGame={handleStartGame}
            isGenerating={isGeneratingAI}
            onGenerateAI={handleGenerateAI}
            videoRef={videoRef}
            hasCamera={hasCamera}
            cameraEnabled={cameraEnabled}
            onToggleCamera={() => setCameraEnabled((c) => !c)}
            motionStats={motionStats}
            onOpenQuestionEditor={(q) => {
              setActiveQuestions(q);
              setIsEditorOpen(true);
            }}
            language={language}
          />
        )}

        {status === 'playing' && activeQuestions.length > 0 && (
          <GameScreen
            questions={activeQuestions}
            currentIndex={currentQuestionIndex}
            timerDuration={timerDuration}
            topicTitle={currentTopic}
            categoryName={activeQuestions[currentQuestionIndex]?.category || currentTopic}
            motionStats={motionStats}
            videoRef={videoRef}
            cameraEnabled={cameraEnabled}
            onToggleCamera={() => setCameraEnabled((c) => !c)}
            isMuted={isMuted}
            onToggleMute={toggleMute}
            isFullscreen={isFullscreen}
            onToggleFullscreen={toggleFullscreen}
            onFinishGame={handleFinishGame}
            onExitGame={handleResetGame}
            freezeCamera={freezeStats}
            unfreezeCamera={unfreezeStats}
            manualSetSide={manualSetSide}
            onNextQuestion={() => setCurrentQuestionIndex((prev) => prev + 1)}
            language={language}
          />
        )}

        {status === 'finished' && (
          <ResultModal
            score={finalScore}
            results={gameResults}
            questions={activeQuestions}
            topic={currentTopic}
            grade={currentGrade}
            onPlayAgain={() => {
              setActiveQuestions(randomizeQuestions(activeQuestions, activeQuestions.length));
              setCurrentQuestionIndex(0);
              setGameResults([]);
              setStatus('playing');
            }}
            onBackToLobby={() => setStatus('setup')}
            language={language}
          />
        )}
      </main>

      {/* Modals */}
      <QuestionEditorModal
        isOpen={isEditorOpen}
        questions={activeQuestions}
        onClose={() => setIsEditorOpen(false)}
        onSave={(updated) => {
          setActiveQuestions(updated);
        }}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        sensitivity={cameraSensitivity}
        onSensitivityChange={setCameraSensitivity}
        isMirrored={isMirrored}
        onToggleMirrored={() => setIsMirrored((m) => !m)}
        cameraEnabled={cameraEnabled}
        onToggleCamera={() => setCameraEnabled((c) => !c)}
      />

      <HelpModal isOpen={isHelpOpen} onClose={() => setIsHelpOpen(false)} />
    </div>
  );
}
