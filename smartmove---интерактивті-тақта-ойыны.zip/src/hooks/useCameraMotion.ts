import { useState, useEffect, useRef, useCallback } from 'react';
import { MotionStats } from '../types';

interface UseCameraMotionOptions {
  enabled: boolean;
  sensitivity?: number; // 1 to 100
  isMirrored?: boolean;
}

export function useCameraMotion({
  enabled,
  sensitivity = 45,
  isMirrored = true,
}: UseCameraMotionOptions) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [hasCamera, setHasCamera] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isReady, setIsReady] = useState<boolean>(false);

  const [stats, setStats] = useState<MotionStats>({
    leftRatio: 0.5,
    rightRatio: 0.5,
    leftMotion: 0,
    rightMotion: 0,
    dominantSide: 'equal',
    totalActivity: 0,
  });

  const prevFrameRef = useRef<Uint8ClampedArray | null>(null);
  const bgFrameRef = useRef<Float32Array | null>(null);
  const smoothedLeftRef = useRef<number>(0.5);
  const smoothedRightRef = useRef<number>(0.5);
  const animFrameIdRef = useRef<number | null>(null);
  const isFrozenRef = useRef<boolean>(false);
  const isAnalyzingRef = useRef<boolean>(false);
  const lastStateEmitRef = useRef<number>(0);

  // Start webcam
  const startCamera = useCallback(async () => {
    try {
      setCameraError(null);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setHasCamera(false);
        setCameraError('Браузерде камера қолдауы табылмады');
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'user',
          width: { ideal: 640 },
          height: { ideal: 480 },
        },
        audio: false,
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
      setHasCamera(true);
      setIsReady(true);
    } catch (err: any) {
      console.warn('Camera initialization error (graceful fallback):', err);
      setCameraError(err.message || 'Камера қосылмады немесе рұқсат берілмеді');
      setHasCamera(false);
      setIsReady(false);
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setHasCamera(false);
    setIsReady(false);
  }, []);

  const freezeStats = useCallback(() => {
    isFrozenRef.current = true;
  }, []);

  const unfreezeStats = useCallback(() => {
    isFrozenRef.current = false;
  }, []);

  const manualSetSide = useCallback((side: 'left' | 'right' | 'equal') => {
    if (side === 'left') {
      smoothedLeftRef.current = 0.85;
      smoothedRightRef.current = 0.15;
    } else if (side === 'right') {
      smoothedLeftRef.current = 0.15;
      smoothedRightRef.current = 0.85;
    } else {
      smoothedLeftRef.current = 0.5;
      smoothedRightRef.current = 0.5;
    }
    setStats({
      leftRatio: smoothedLeftRef.current,
      rightRatio: smoothedRightRef.current,
      leftMotion: 50,
      rightMotion: 50,
      dominantSide: side,
      totalActivity: 80,
    });
  }, []);

  useEffect(() => {
    if (enabled) {
      startCamera();
    } else {
      stopCamera();
    }

    return () => {
      stopCamera();
    };
  }, [enabled, startCamera, stopCamera]);

  // Frame processing loop
  useEffect(() => {
    if (!enabled || !hasCamera) return;

    const procWidth = 60;
    const procHeight = 40;
    const offscreen = document.createElement('canvas');
    offscreen.width = procWidth;
    offscreen.height = procHeight;
    const offCtx = offscreen.getContext('2d', { willReadFrequently: true });

    let lastAnalyzeTime = 0;
    const targetFpsInterval = 200; // 5 fps analysis is plenty for classroom side detection and doesn't freeze React

    const analyzeLoop = (timestamp: number) => {
      animFrameIdRef.current = requestAnimationFrame(analyzeLoop);

      if (isFrozenRef.current) return;
      if (timestamp - lastAnalyzeTime < targetFpsInterval) return;
      lastAnalyzeTime = timestamp;

      const video = videoRef.current;
      if (!video || video.readyState < 2 || !offCtx) return;

      try {
        offCtx.save();
        if (isMirrored) {
          offCtx.translate(procWidth, 0);
          offCtx.scale(-1, 1);
        }
        offCtx.drawImage(video, 0, 0, procWidth, procHeight);
        offCtx.restore();

        const imgData = offCtx.getImageData(0, 0, procWidth, procHeight);
        const data = imgData.data;
        const pixelCount = procWidth * procHeight;

        if (!prevFrameRef.current) {
          prevFrameRef.current = new Uint8ClampedArray(data);
          bgFrameRef.current = new Float32Array(pixelCount);
          for (let i = 0; i < pixelCount; i++) {
            const idx = i * 4;
            bgFrameRef.current[i] = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
          }
          return;
        }

        const prev = prevFrameRef.current;
        const bg = bgFrameRef.current!;

        const motionThreshold = Math.max(12, 50 - sensitivity * 0.4);
        const bgThreshold = Math.max(16, 45 - sensitivity * 0.3);

        let leftCount = 0;
        let rightCount = 0;
        let leftActivity = 0;
        let rightActivity = 0;

        const midX = procWidth / 2;
        const deadBand = procWidth * 0.06;

        for (let y = 0; y < procHeight; y++) {
          const rowOffset = y * procWidth;
          for (let x = 0; x < procWidth; x++) {
            const pIndex = rowOffset + x;
            const idx = pIndex * 4;

            const r = data[idx];
            const g = data[idx + 1];
            const b = data[idx + 2];
            const currentLum = 0.299 * r + 0.587 * g + 0.114 * b;

            const pr = prev[idx];
            const pg = prev[idx + 1];
            const pb = prev[idx + 2];
            const diff = Math.abs(r - pr) + Math.abs(g - pg) + Math.abs(b - pb);

            const bgDiff = Math.abs(currentLum - bg[pIndex]);
            bg[pIndex] = bg[pIndex] * 0.99 + currentLum * 0.01;

            const isMotion = diff > motionThreshold;
            const isPresence = bgDiff > bgThreshold;

            if (x < midX - deadBand) {
              if (isMotion) leftActivity += 1;
              if (isPresence) leftCount += 1;
            } else if (x > midX + deadBand) {
              if (isMotion) rightActivity += 1;
              if (isPresence) rightCount += 1;
            }

            prev[idx] = r;
            prev[idx + 1] = g;
            prev[idx + 2] = b;
          }
        }

        const leftTotal = leftCount * 0.6 + leftActivity * 0.4;
        const rightTotal = rightCount * 0.6 + rightActivity * 0.4;
        const combined = leftTotal + rightTotal;

        let targetLeftRatio = 0.5;
        let targetRightRatio = 0.5;

        if (combined > 20) {
          targetLeftRatio = leftTotal / combined;
          targetRightRatio = rightTotal / combined;
        }

        const smoothing = 0.25;
        smoothedLeftRef.current = smoothedLeftRef.current * (1 - smoothing) + targetLeftRatio * smoothing;
        smoothedRightRef.current = smoothedRightRef.current * (1 - smoothing) + targetRightRatio * smoothing;

        const finalLeft = Math.round(smoothedLeftRef.current * 100) / 100;
        const finalRight = Math.round(smoothedRightRef.current * 100) / 100;

        let domSide: 'left' | 'right' | 'equal' | 'none' = 'equal';
        if (combined < 15) {
          domSide = 'none';
        } else if (finalLeft > finalRight + 0.12) {
          domSide = 'left';
        } else if (finalRight > finalLeft + 0.12) {
          domSide = 'right';
        }

        // Only setState every 300ms to keep main thread completely smooth
        const now = Date.now();
        if (now - lastStateEmitRef.current > 300) {
          lastStateEmitRef.current = now;
          setStats({
            leftRatio: finalLeft,
            rightRatio: finalRight,
            leftMotion: Math.min(100, Math.round((leftActivity / 100) * 100)),
            rightMotion: Math.min(100, Math.round((rightActivity / 100) * 100)),
            dominantSide: domSide,
            totalActivity: Math.min(100, Math.round((combined / 250) * 100)),
          });
        }
      } catch (err) {
        console.warn('Analysis frame skipped:', err);
      }
    };

    animFrameIdRef.current = requestAnimationFrame(analyzeLoop);

    return () => {
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
    };
  }, [enabled, hasCamera, sensitivity, isMirrored]);

  return {
    videoRef,
    hasCamera,
    cameraError,
    isReady,
    stats,
    startCamera,
    stopCamera,
    freezeStats,
    unfreezeStats,
    manualSetSide,
  };
}
