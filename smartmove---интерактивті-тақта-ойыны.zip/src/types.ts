export interface GameQuestion {
  id: string;
  question: string;
  leftOption: string;
  rightOption: string;
  correctSide: 'left' | 'right';
  explanation: string;
  funFact?: string;
  category?: string;
}

export type GameStatus = 'setup' | 'playing' | 'revealing' | 'finished';

export interface MotionStats {
  leftRatio: number; // 0 to 1
  rightRatio: number; // 0 to 1
  leftMotion: number; // raw activity
  rightMotion: number; // raw activity
  dominantSide: 'left' | 'right' | 'equal' | 'none';
  totalActivity: number;
}

export interface RoundResult {
  questionId: string;
  correctSide: 'left' | 'right';
  dominantSide: 'left' | 'right' | 'equal' | 'none';
  isClassCorrect: boolean;
  leftPercentage: number;
  rightPercentage: number;
}

export interface TopicPreset {
  id: string;
  name: string;
  emoji: string;
  grade: string;
  description: string;
}
