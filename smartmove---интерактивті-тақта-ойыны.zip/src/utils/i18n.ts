export type Language = 'kk' | 'ru' | 'en';

export interface Translations {
  gameTitle: string;
  gameSubtitle: string;
  smartboardBadge: string;
  heroDesc: string;
  rule1Title: string;
  rule1Desc: string;
  rule2Title: string;
  rule2Desc: string;
  rule3Title: string;
  rule3Desc: string;
  step1Title: string;
  step1Hint: string;
  customTopicPlaceholder: string;
  clear: string;
  step2Title: string;
  step3Count: string;
  step3Timer: string;
  questionsWord: string;
  secondsWord: string;
  btnStartAI: string;
  btnGenerating: string;
  btnStartInstant: string;
  cameraTestTitle: string;
  cameraOn: string;
  cameraOff: string;
  cameraDisabledHint: string;
  cameraAltHint: string;
  sideA: string;
  sideB: string;
  leftChoice: string;
  rightChoice: string;
  selectedQuestions: string;
  randomizedHint: string;
  edit: string;
  nextQuestionIn: string;
  nextQuestionBtn: string;
  correctBadge: string;
  wrongBadge: string;
  correctCountLabel: string;
  wrongCountLabel: string;
  timeRemaining: string;
  resultsTitle: string;
  resultsSubtitle: string;
  playAgain: string;
  backToLobby: string;
  accuracy: string;
  autoNextQuestionNote: string;
  // ЖАҢА МӘТІН БОЙЫНША ҚҰРАСТЫРУ
  textPromptTabTitle: string;
  presetTabTitle: string;
  textPromptLabel: string;
  textPromptPlaceholder: string;
  textPromptHint: string;
  btnGenerateFromText: string;
}

export const TRANSLATIONS: Record<Language, Translations> = {
  kk: {
    gameTitle: 'ОҢҒА МА? СОЛҒА МА?',
    gameSubtitle: 'Интерактивті Смарт-Тақта Ойыны',
    smartboardBadge: 'ЖИ Тақта',
    heroDesc: 'Сұрақ шыққанда 10 секундта сынып оқушылары дұрыс жауап жағына тұрады. Таңдау аяқталған соң дұрыс жақ ЖАСЫЛ, қате жақ ҚЫЗЫЛ болып жанады және келесі сұраққа АВТОМАТТЫ өтеді!',
    rule1Title: 'Өз мәтініңіз не тақырып',
    rule1Desc: 'Оқулықтан кез келген мәтін не тақырып беріңіз',
    rule2Title: 'Камера сынағы',
    rule2Desc: 'Тақта ортасы қақ бөлінеді, оқушылар қозғалады',
    rule3Title: 'Авто-ауысу & Рандом',
    rule3Desc: 'Жауаптар кездейсоқ түседі, 3 сек кейін авто-өтеді!',
    step1Title: '1. Ойын тақырыбы немесе өз мәтініңіз:',
    step1Hint: 'Мәтінді көшіріп қойыңыз — ЖИ соның ішінен ғана сұрақ құрастырады',
    customTopicPlaceholder: 'Немесе қысқа тақырыпты жазыңыз (Мысалы: Судың қасиеттері, 7-сынып Химия...)',
    clear: 'Тазарту',
    step2Title: '2. Сынып деңгейі (оқушылар жасына қарай бейімделеді):',
    step3Count: 'Сұрақ саны:',
    step3Timer: 'Ойлану уақыты:',
    questionsWord: 'сұрақ',
    secondsWord: 'сек',
    btnStartAI: 'ЖИ-МЕН ЖАҢА ОЙЫН',
    btnGenerating: 'ЖИ сұрақтарды құрастыруда...',
    btnStartInstant: 'Бірден бастау',
    cameraTestTitle: 'Камера мен Тақта сынағы',
    cameraOn: 'Қосулы',
    cameraOff: 'Қосу',
    cameraDisabledHint: 'Камера өшірулі немесе рұқсат берілмеген',
    cameraAltHint: 'Ойын пернетақта немесе сенсорлық тақта арқылы да ойнала береді',
    sideA: 'А жағы',
    sideB: 'В жағы',
    leftChoice: 'СОЛҒА (А)',
    rightChoice: 'ОҢҒА (В)',
    selectedQuestions: 'Таңдалған сұрақтар:',
    randomizedHint: 'Жауаптар кездейсоқ (50% сол, 50% оң) ретпен беріледі',
    edit: 'Өңдеу',
    nextQuestionIn: 'Келесі сұраққа өту:',
    nextQuestionBtn: 'КЕЛЕСІ СҰРАҚҚА ӨТУ →',
    correctBadge: 'ДҰРЫС! ТАМАША!',
    wrongBadge: 'ҚАТЕ!',
    correctCountLabel: 'Дұрыс',
    wrongCountLabel: 'Қате',
    timeRemaining: 'сек',
    resultsTitle: 'ОЙЫН АЯҚТАЛДЫ!',
    resultsSubtitle: 'Сыныптың білім мен қозғалыс нәтижесі',
    playAgain: 'ҚАЙТА ОЙНАУ 🔄',
    backToLobby: 'БАСТЫ МӘЗІРГЕ 🏠',
    accuracy: 'Дәлдік көрсеткіші',
    autoNextQuestionNote: 'Оқушылар жауап беріп болған соң 3 секундта келесі сұраққа автоматты өтеді',
    textPromptTabTitle: '📝 Өз мәтінімді енгізу',
    presetTabTitle: '📚 Дайын пәндер',
    textPromptLabel: 'Оқулықтан немесе парақтан мәтінді/ақпаратты осында қойыңыз:',
    textPromptPlaceholder: 'Мұнда сабақ мәтінін, параграфты немесе кез келген ақпаратты қойыңыз. Мысалы:\n«Су – түссіз, иіссіз сұйықтық. Оның химиялық формуласы H2O. Ол 100 градуста қайнайды және 0 градуста қатады. Адам ағзасының 70%-ы судан тұрады...»\nЖасанды интеллект дәл осы ақпарат бойынша оқушыларға 10 сұрақ құрастырады!',
    textPromptHint: 'ЖИ сұрақтарды тек сіз берген осы мәліметтерден алады',
    btnGenerateFromText: 'ЖИ МӘТІН БОЙЫНША СҰРАҚТАР ҚҰРАСТЫРУ',
  },
  ru: {
    gameTitle: 'ВПРАВО ИЛИ ВЛЕВО?',
    gameSubtitle: 'Интерактивная игра для смарт-доски',
    smartboardBadge: 'ИИ Доска',
    heroDesc: 'После появления вопроса у класса есть 10 секунд, чтобы встать на правильную сторону. Затем верная сторона подсветится ЗЕЛЕНЫМ, неверная — КРАСНЫМ, и игра АВТОМАТИЧЕСКИ перейдет к следующему вопросу!',
    rule1Title: 'Свой текст или тема',
    rule1Desc: 'Вставьте любой учебный текст или параграф',
    rule2Title: 'Тест камеры',
    rule2Desc: 'Экран делится пополам, камера фиксирует движение',
    rule3Title: 'Автопереход & Рандом',
    rule3Desc: 'Варианты перемешиваются, переход через 3 секунды!',
    step1Title: '1. Тема игры или ваш текст:',
    step1Hint: 'Вставьте текст — ИИ составит вопросы строго по нему',
    customTopicPlaceholder: 'Или введите тему (Например: Свойства воды, Химия 7 класс...)',
    clear: 'Очистить',
    step2Title: '2. Уровень класса (адаптируется под возраст):',
    step3Count: 'Количество вопросов:',
    step3Timer: 'Время на размышление:',
    questionsWord: 'вопросов',
    secondsWord: 'сек',
    btnStartAI: 'ИГРА С ИИ',
    btnGenerating: 'ИИ составляет вопросы...',
    btnStartInstant: 'Быстрый старт',
    cameraTestTitle: 'Проверка камеры и доски',
    cameraOn: 'Вкл',
    cameraOff: 'Выкл',
    cameraDisabledHint: 'Камера отключена или доступ не предоставлен',
    cameraAltHint: 'Можно играть через сенсорный экран или клавиатуру (стрелки)',
    sideA: 'Сторона А',
    sideB: 'Сторона В',
    leftChoice: 'ВЛЕВО (А)',
    rightChoice: 'ВПРАВО (В)',
    selectedQuestions: 'Выбрано вопросов:',
    randomizedHint: 'Ответы перемешиваются случайно (50% лево, 50% право)',
    edit: 'Изменить',
    nextQuestionIn: 'Следующий вопрос через:',
    nextQuestionBtn: 'СЛЕДУЮЩИЙ ВОПРОС →',
    correctBadge: 'ВЕРНО! ОТЛИЧНО!',
    wrongBadge: 'НЕВЕРНО!',
    correctCountLabel: 'Верно',
    wrongCountLabel: 'Ошибок',
    timeRemaining: 'сек',
    resultsTitle: 'ИГРА ОКОНЧЕНА!',
    resultsSubtitle: 'Результаты знаний и активности класса',
    playAgain: 'ИГРАТЬ СНОВА 🔄',
    backToLobby: 'В ГЛАВНОЕ МЕНЮ 🏠',
    accuracy: 'Точность ответов',
    autoNextQuestionNote: 'После ответа переход к следующему вопросу происходит автоматически через 3 секунды',
    textPromptTabTitle: '📝 Вставить свой текст',
    presetTabTitle: '📚 Готовые темы',
    textPromptLabel: 'Вставьте учебный материал или текст параграфа:',
    textPromptPlaceholder: 'Вставьте сюда текст урока или конспекта. Например:\n«Вода — прозрачная жидкость без запаха с формулой H2O. Кипит при 100°C и замерзает при 0°C. Организм человека на 70% состоит из воды...»\nИскусственный интеллект составит 10 вопросов строго по этому тексту!',
    textPromptHint: 'ИИ создаст вопросы исключительно на основе вашего текста',
    btnGenerateFromText: 'СОЗДАТЬ ВОПРОСЫ ПО ЭТОМУ ТЕКСТУ',
  },
  en: {
    gameTitle: 'RIGHT OR LEFT?',
    gameSubtitle: 'Interactive Smartboard Motion Quiz',
    smartboardBadge: 'AI Board',
    heroDesc: 'When the question appears, students have 10 seconds to move to the correct side. The correct side glows GREEN, incorrect glows RED, and the quiz AUTOMATICALLY advances to the next question!',
    rule1Title: 'Custom Text or Topic',
    rule1Desc: 'Paste any paragraph or textbook snippet',
    rule2Title: 'Camera Test',
    rule2Desc: 'Screen splits in half, camera tracks movement',
    rule3Title: 'Auto-Advance & Random',
    rule3Desc: 'Answers randomize and auto-advance in 3 seconds!',
    step1Title: '1. Game Topic or Custom Text:',
    step1Hint: 'Paste your information — AI will craft quiz questions strictly from it',
    customTopicPlaceholder: 'Or enter custom topic (e.g., Chemistry, Water properties...)',
    clear: 'Clear',
    step2Title: '2. Grade Level (adapts to student age):',
    step3Count: 'Question Count:',
    step3Timer: 'Thinking Time:',
    questionsWord: 'questions',
    secondsWord: 'sec',
    btnStartAI: 'NEW AI GAME',
    btnGenerating: 'AI is generating questions...',
    btnStartInstant: 'Start Now',
    cameraTestTitle: 'Camera & Smartboard Test',
    cameraOn: 'On',
    cameraOff: 'Off',
    cameraDisabledHint: 'Camera is off or permission was not granted',
    cameraAltHint: 'You can also play via touchscreen or keyboard arrow keys',
    sideA: 'Side A',
    sideB: 'Side B',
    leftChoice: 'LEFT (A)',
    rightChoice: 'RIGHT (B)',
    selectedQuestions: 'Selected questions:',
    randomizedHint: 'Answers are randomized 50/50 left and right',
    edit: 'Edit',
    nextQuestionIn: 'Next question in:',
    nextQuestionBtn: 'NEXT QUESTION →',
    correctBadge: 'CORRECT! GREAT JOB!',
    wrongBadge: 'WRONG!',
    correctCountLabel: 'Correct',
    wrongCountLabel: 'Wrong',
    timeRemaining: 'sec',
    resultsTitle: 'GAME FINISHED!',
    resultsSubtitle: 'Class motion & knowledge score',
    playAgain: 'PLAY AGAIN 🔄',
    backToLobby: 'MAIN MENU 🏠',
    accuracy: 'Class Accuracy',
    autoNextQuestionNote: 'After students answer, automatically advances to next question in 3 seconds',
    textPromptTabTitle: '📝 Paste Custom Text',
    presetTabTitle: '📚 Preset Subjects',
    textPromptLabel: 'Paste lesson notes or textbook paragraph:',
    textPromptPlaceholder: 'Paste any material here. Example:\n"Water is a clear liquid with formula H2O. It boils at 100°C and freezes at 0°C. 70% of the human body is water..."\nAI will generate 10 questions strictly based on this content!',
    textPromptHint: 'AI will extract quiz questions exclusively from this text',
    btnGenerateFromText: 'GENERATE QUESTIONS FROM THIS TEXT',
  },
};
