import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import { PRESET_QUESTIONS_BY_TOPIC, randomizeQuestions } from './src/utils/presets';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json());

export interface GameQuestion {
  id: string;
  question: string;
  leftOption: string;
  rightOption: string;
  correctSide: 'left' | 'right';
  explanation: string;
  funFact?: string;
  category?: string;
}

// 50/50 кездейсоқ жауап жақтарын араластыру функциясы
function shuffleQuestionOptions(q: GameQuestion): GameQuestion {
  const shouldSwap = Math.random() > 0.5;
  if (shouldSwap) {
    return {
      ...q,
      leftOption: q.rightOption,
      rightOption: q.leftOption,
      correctSide: q.correctSide === 'left' ? 'right' : 'left',
    };
  }
  return q;
}

// Тақырып бойынша алдын ала дайындалған тереңдетілген мектеп сұрақтары қоры
function getCuratedTopicQuestions(topic: string, count: number): GameQuestion[] | null {
  const clean = topic.toLowerCase().trim();

  // Химия, су, қасиеттер
  if (
    clean.includes('су') ||
    clean.includes('хим') ||
    clean.includes('вод') ||
    clean.includes('water') ||
    clean.includes('h2o') ||
    clean.includes('ерітінді')
  ) {
    const list = PRESET_QUESTIONS_BY_TOPIC['chemistry_water'] || [];
    return randomizeQuestions(list, count);
  }

  // Қазақстан тарихы, хандар, батырлар
  if (
    clean.includes('тарих') ||
    clean.includes('хан') ||
    clean.includes('батыр') ||
    clean.includes('керей') ||
    clean.includes('жәнібек') ||
    clean.includes('абылай') ||
    clean.includes('шайқас') ||
    clean.includes('сақ') ||
    clean.includes('история') ||
    clean.includes('history')
  ) {
    const list = PRESET_QUESTIONS_BY_TOPIC['history_kz'] || [];
    return randomizeQuestions(list, count);
  }

  // Физика, Ньютон заңдары, жарық, ток
  if (
    clean.includes('физик') ||
    clean.includes('ньютон') ||
    clean.includes('ток') ||
    clean.includes('жарық') ||
    clean.includes('жылдамдық') ||
    clean.includes('энергия') ||
    clean.includes('physics')
  ) {
    const list = PRESET_QUESTIONS_BY_TOPIC['physics_science'] || [];
    return randomizeQuestions(list, count);
  }

  // Абай, әдебиет, қарасөз
  if (
    clean.includes('абай') ||
    clean.includes('әдебиет') ||
    clean.includes('өлең') ||
    clean.includes('жазушы') ||
    clean.includes('литература') ||
    clean.includes('literature')
  ) {
    const list = PRESET_QUESTIONS_BY_TOPIC['abai_literature'] || [];
    return randomizeQuestions(list, count);
  }

  // Ғарыш, Күн, планеталар
  if (
    clean.includes('ғарыш') ||
    clean.includes('күн') ||
    clean.includes('планета') ||
    clean.includes('юпитер') ||
    clean.includes('марс') ||
    clean.includes('ай') ||
    clean.includes('космос') ||
    clean.includes('space')
  ) {
    const list = PRESET_QUESTIONS_BY_TOPIC['space_science'] || [];
    return randomizeQuestions(list, count);
  }

  // Информатика, ЖИ, компьютер
  if (
    clean.includes('информ') ||
    clean.includes('комп') ||
    clean.includes('жи') ||
    clean.includes('ai') ||
    clean.includes('алгоритм') ||
    clean.includes('бағдарлама') ||
    clean.includes('код')
  ) {
    const list = PRESET_QUESTIONS_BY_TOPIC['informatics_ai'] || [];
    return randomizeQuestions(list, count);
  }

  return null;
}

// Егер желі толық үзілсе немесе ЖИ мүлдем жауап бермесе, таза дербес табиғи викториналық сұрақтар генераторы
// (Сұрақта ЕШҚАШАН "мәтін бойынша", "тұжырым бойынша" сөздері ЖОҚ! Тек оқушыға тікелей қойылатын нақты сұрақ!)
function buildRealNaturalQuestionsFromContent(
  rawContent: string,
  topic: string,
  grade: string,
  count: number,
  language: string
): GameQuestion[] {
  const sentences = rawContent
    .split(/[.!?\n;]+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 5);

  const pool: GameQuestion[] = [];

  // Сандық көрсеткіштер мен фактілер
  sentences.forEach((sentence, idx) => {
    // 1. Анықтамалар: X – Y немесе X дегеніміз Y
    const defMatch = sentence.match(/^([^–—\-:]+)\s*[–—\-:]\s*(.+)$/i) || sentence.match(/^(.+?)\s+дегеніміз\s+(.+)$/i);
    if (defMatch && defMatch[1].length < 40 && defMatch[2].length > 4) {
      const term = defMatch[1].trim();
      const val = defMatch[2].trim();
      pool.push({
        id: `gen_def_${Date.now()}_${idx}`,
        question:
          language === 'ru'
            ? `Что такое ${term}?`
            : language === 'en'
            ? `What is ${term}?`
            : `${term} дегеніміз не?`,
        leftOption: val.slice(0, 30),
        rightOption: language === 'ru' ? 'Иное свойство' : language === 'en' ? 'Other property' : 'Басқа қасиет',
        correctSide: 'left',
        explanation: `${term} – ${val}`,
        funFact: 'Маңызды мектеп ұғымы!',
        category: topic || 'Сабақ сұрағы',
      });
      return;
    }

    // 2. Температура, пайыз, сан, жыл
    const tempMatch = sentence.match(/(\d+[\d.,]*)\s*(°C|C|градус)/i);
    if (tempMatch) {
      const num = tempMatch[1];
      const fake = Number(num) === 100 ? '80°C' : Number(num) === 0 ? '-10°C' : `${Number(num) + 15}°C`;
      pool.push({
        id: `gen_num_${Date.now()}_${idx}`,
        question:
          language === 'ru'
            ? `Какова температура (${tempMatch[2]})?`
            : language === 'en'
            ? `What is the temperature?`
            : `Қайнау немесе қату температурасы қандай?`,
        leftOption: `${num}°C`,
        rightOption: fake,
        correctSide: 'left',
        explanation: sentence,
        funFact: 'Физикалық-химиялық көрсеткіш!',
        category: topic || 'Ғылым',
      });
      return;
    }

    // 3. Пайыз (% немесе процент)
    const percentMatch = sentence.match(/(\d+[\d.,]*)\s*(%|пайыз|процент)/i);
    if (percentMatch) {
      const pct = percentMatch[1];
      const fakePct = Number(pct) > 50 ? '30%' : '80%';
      pool.push({
        id: `gen_pct_${Date.now()}_${idx}`,
        question:
          language === 'ru'
            ? `Какова доля или процентное содержание?`
            : language === 'en'
            ? `What is the percentage?`
            : `Көрсеткіш неше пайызды құрайды?`,
        leftOption: `${pct}%`,
        rightOption: fakePct,
        correctSide: 'left',
        explanation: sentence,
        funFact: 'Нақты сандық дерек!',
        category: topic || 'Сандар',
      });
      return;
    }

    // 4. Формулалар (H2O, NaCl, CO2, O2, Fe, H2SO4 т.б.)
    const formulaMatch = sentence.match(/\b([A-Z][a-z]?\d*(?:[A-Z][a-z]?\d*)*)\b/);
    if (formulaMatch && formulaMatch[1].length >= 2 && !['HTML', 'CSS', 'JS', 'API'].includes(formulaMatch[1])) {
      const formula = formulaMatch[1];
      pool.push({
        id: `gen_form_${Date.now()}_${idx}`,
        question:
          language === 'ru'
            ? `Какова правильная химическая формула?`
            : language === 'en'
            ? `What is the correct chemical formula?`
            : `Дұрыс химиялық формуласы қандай?`,
        leftOption: formula,
        rightOption: formula === 'H2O' ? 'CO2' : 'H2O',
        correctSide: 'left',
        explanation: sentence,
        funFact: 'Химиялық формула!',
        category: topic || 'Химия',
      });
      return;
    }

    // 5. Қарапайым тікелей мазмұнды сауал
    const words = sentence.split(/\s+/);
    if (words.length >= 4) {
      const key = words[words.length - 1].replace(/[.,!?;:]/g, '');
      const stem = words.slice(0, words.length - 1).join(' ');
      pool.push({
        id: `gen_direct_${Date.now()}_${idx}`,
        question: `${stem} ... ?`,
        leftOption: key,
        rightOption: language === 'ru' ? 'Другое' : language === 'en' ? 'Incorrect' : 'Қате сөз',
        correctSide: 'left',
        explanation: sentence,
        funFact: 'Сабақ мазмұны!',
        category: topic || 'Білім',
      });
    }
  });

  // Егер жеткіліксіз болса, дайын сапалы сұрақтармен 10-ға жеткіземіз
  const backupPresets = PRESET_QUESTIONS_BY_TOPIC['chemistry_water'] || [];
  let bIdx = 0;
  while (pool.length < count) {
    if (bIdx < backupPresets.length) {
      pool.push({
        ...backupPresets[bIdx],
        id: `back_${Date.now()}_${bIdx}`,
      });
      bIdx++;
    } else {
      break;
    }
  }

  return pool.slice(0, count).map(shuffleQuestionOptions);
}

// Gemini арқылы сұрақтар генерациялау (gemini-3.1-flash-lite, gemini-3.8-flash)
async function callGemini(
  topic: string,
  rawContent: string,
  grade: string,
  count: number,
  language: string,
  apiKey: string
): Promise<GameQuestion[] | null> {
  // Квота шегіне жетпеген немесе лимиті жоғары модельдер кезегі:
  const modelsToTry = ['gemini-3.1-flash-lite', 'gemini-3.8-flash'];

  const langInstruction =
    language === 'ru'
      ? 'Язык вопросов и вариантов: ЧИСТЫЙ РУССКИЙ ЯЗЫК.'
      : language === 'en'
      ? 'Language of questions and options: CLEAN ENGLISH.'
      : 'Барлық сұрақтар мен нұсқалар МІНДЕТТІ ТҮРДЕ ТАЗА ҚАЗАҚ ТІЛІНДЕ болуы тиіс.';

  let prompt = '';

  if (rawContent && rawContent.trim().length > 15) {
    // Пайдаланушы нақты мәтін не ақпарат бергенде:
    prompt = `Сіз мектеп интерактивті смарт-тақтасына арналған викторина сұрақтарын құрастырушысыз.
Мұғалім сабақтан мынадай ақпарат берді:
"""
${rawContent.trim()}
"""

Тақырып: "${topic || 'Берілген ақпарат'}"
Сынып: "${grade}"
Сұрақ саны: МІНДЕТТІ ТҮРДЕ ДӘЛ ${count} СҰРАҚ!

ҚАТАҢ БАСТЫ ТАЛАПТАР (ӨТЕ МАҢЫЗДЫ):
1. ОҚУШЫЛАР ЭКРАННАН МӘТІНДІ КӨРМЕЙДІ! Сондықтан сұрақтың ішінде «Мәтін бойынша...», «Мәтінде не айтылған...», «Берілген ақпаратқа сәйкес...», «Тұжырым дұрыс па...» деген сияқты СӨЗДЕРДІ ЖАЗУҒА ҚАТАҢ ТЫЙЫМ САЛЫНАДЫ!
2. Сұрақтар кәдімгі мектеп оқушысына қойылатын нағыз тікелей викториналық сұрақ болуы керек!
   ДҰРЫС МЫСАЛДАР:
   - "Судың химиялық формуласы қандай?" (А нұсқасы: H2O | В нұсқасы: CO2)
   - "Су неше градуста қайнайды?" (А нұсқасы: 100°C | В нұсқасы: 50°C)
   - "Адам денесінің неше пайызын су құрайды?" (А нұсқасы: 70% | В нұсқасы: 25%)
   - "Ас тұзының химиялық аты қандай?" (А нұсқасы: Натрий хлориді | В нұсқасы: Калий оксиді)
   - "Судың неше агрегаттық күйі бар?" (А нұсқасы: 3 күй | В нұсқасы: 6 күй)
3. Деректерді (сандар, формулалар, атаулар) мұғалім берген жоғарыдағы ақпараттан алыңыз.
4. "leftOption" және "rightOption" қысқа, нақты жауаптар (1-3 сөз). Ешқандай «Иә/Жоқ» немесе «Дұрыс/Қате» емес, нақты сандар, формулалар мен атаулар болсын.
5. "correctSide" ТЕК "left" немесе "right" мәнін қабылдайды. 50% left, 50% right болып КЕЗДЕЙСОҚ АРАЛАССЫН!
6. ${langInstruction}`;
  } else {
    // Жалпы тақырып бойынша:
    prompt = `Сіз мектеп интерактивті тақтасына арналған кәсіби сұрақ құрастырушысыз.
Тақырып: "${topic}"
Сынып: "${grade}"
Сұрақ саны: МІНДЕТТІ ТҮРДЕ ДӘЛ ${count} СҰРАҚ!

ҚАТАҢ ТАЛАПТАР:
1. Тек тікелей нақты сұрақтар («Формуласы қандай?», «Неше градус?», «Қай жылы?», «Кім ашты?»).
2. 2 нұсқа: leftOption және rightOption (1-3 сөз).
3. correctSide кездейсоқ 50% left, 50% right аралассын.
4. ${langInstruction}`;
  }

  for (const modelName of modelsToTry) {
    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const response = await ai.models.generateContent({
        model: modelName,
        contents: prompt,
        config: {
          systemInstruction:
            'You are an expert school quiz creator. Strictly generate real, direct educational questions (e.g. "What is the boiling point of water?", "What is the chemical formula of salt?"). NEVER write "According to the text" or "Is this statement true". Students only see the question on screen.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                question: { type: Type.STRING },
                leftOption: { type: Type.STRING },
                rightOption: { type: Type.STRING },
                correctSide: { type: Type.STRING },
                explanation: { type: Type.STRING },
                funFact: { type: Type.STRING },
                category: { type: Type.STRING },
              },
              required: ['question', 'leftOption', 'rightOption', 'correctSide', 'explanation'],
            },
          },
        },
      });

      const text = response.text?.trim() || '[]';
      const parsed: any[] = JSON.parse(text);

      if (Array.isArray(parsed) && parsed.length >= 3) {
        let questions: GameQuestion[] = parsed.map((q, idx) => {
          const isLeft = String(q.correctSide).toLowerCase().includes('left');
          return {
            id: q.id || `ai_${Date.now()}_${idx}`,
            question: q.question,
            leftOption: q.leftOption,
            rightOption: q.rightOption,
            correctSide: isLeft ? ('left' as const) : ('right' as const),
            explanation: q.explanation || `Дұрыс жауабы: ${isLeft ? q.leftOption : q.rightOption}`,
            funFact: q.funFact || 'Керемет жауап!',
            category: topic || 'Сабақ',
          };
        });

        // 10 сұраққа дейін толықтыру
        while (questions.length < count) {
          const extra = questions.map((item, i) => {
            const flip = Math.random() > 0.5;
            return {
              ...item,
              id: `${item.id}_ext_${questions.length + i}`,
              leftOption: flip ? item.rightOption : item.leftOption,
              rightOption: flip ? item.leftOption : item.rightOption,
              correctSide: (flip ? (item.correctSide === 'left' ? 'right' : 'left') : item.correctSide) as 'left' | 'right',
            };
          });
          questions = [...questions, ...extra];
        }

        const randomized = questions.slice(0, count).map(shuffleQuestionOptions);
        return randomized;
      }
    } catch (err: any) {
      console.warn(`Model ${modelName} attempt failed:`, err?.message || err);
    }
  }

  return null;
}

app.post('/api/generate-questions', async (req, res) => {
  const {
    topic = 'Судың қасиеттері мен Химия',
    customText = '',
    grade = '5-сынып',
    count = 10,
    language = 'kk',
  } = req.body;
  const numQuestions = Math.min(Math.max(Number(count) || 10, 5), 10);

  const activeKey = process.env.GEMINI_API_KEY || process.env.API_KEY || '';

  // 1. ЖИ арқылы кәдімгі нағыз тікелей мектеп сұрақтарын («Мәтін бойынша» сөзінсіз) құрастыру
  if (activeKey) {
    const aiQuestions = await callGemini(topic, customText, grade, numQuestions, language, activeKey);
    if (aiQuestions && aiQuestions.length >= numQuestions) {
      return res.json({
        success: true,
        source: 'gemini_ai',
        questions: aiQuestions,
      });
    }
  }

  // 2. Егер пайдаланушы мәтін берсе, тікелей табиғи сұрақтар жасау («Мәтін бойынша» сөзінсіз)
  if (customText && customText.trim().length > 15) {
    const fromText = buildRealNaturalQuestionsFromContent(customText, topic, grade, numQuestions, language);
    return res.json({
      success: true,
      source: 'custom_text_parser',
      questions: fromText,
    });
  }

  // 3. Тақырып бойынша дайын білім қорынан алу
  const curated = getCuratedTopicQuestions(topic, numQuestions);
  if (curated) {
    return res.json({
      success: true,
      source: 'knowledge_base',
      questions: curated,
    });
  }

  // 4. Су мен химиядан нақты дайын сұрақтар
  const defaultList = PRESET_QUESTIONS_BY_TOPIC['chemistry_water'] || [];
  return res.json({
    success: true,
    source: 'preset_fallback',
    questions: randomizeQuestions(defaultList, numQuestions),
  });
});

async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
